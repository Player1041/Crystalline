<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="sky" tilewidth="32" tileheight="32" spacing="1" tilecount="18" columns="6">
 <image source="../tilesets/sky.png" width="197" height="98"/>
</tileset>
